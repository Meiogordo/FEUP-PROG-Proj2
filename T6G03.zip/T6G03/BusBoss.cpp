#include "BusBoss.h"

BusBoss::BusBoss() {

}

BusBoss::~BusBoss() {

}

bool BusBoss::createNewDriver() {
	unsigned int newID;

	cout << "Introduza o ID do novo condutor: ";

	while (true) {
		cin >> newID;
		if (cin.fail()) {
			cout << "ID inv�lido, por favor introduza um ID v�lido (n�mero inteiro)." << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	//Checking if a driver with the given ID already exists (number of elements bigger than 0)
	//Because we are using a map and not multimap .count will always be either 0 or 1 but > 0 is used for clarity
	bool driverExists = (drivers.count(newID) > 0);
	if (driverExists) {
		cout << "O ID dado j� existe. Dois condutores diferentes n�o podem ter o mesmo ID.\nAbortando o processo de adi��o de condutor..." << endl;
		return false;
	}

	//Getting input from user about the driver

	string name; //the driver's name

	cout << "Qual o nome do condutor?" << endl;
	//With the testing done, this is needed if we are to use getline after using cin as a stream
	cin.ignore(10000, '\n');
	getline(cin, name); //using getline because the driver's name can have spaces
	Utilities::trimString(name); //trimming unnecessary whitespace from the driver name

	unsigned int shiftsize; //the size of the driver's shift - number of hours he can work per day
	cout << "Qual o tamanho m�ximo de um turno horas que o condutor pode efetuar?" << endl;

	while (true) {
		cin >> shiftsize;
		if (cin.fail()) {
			cout << "Tamanho de turno inv�lido, por favor introduza um tamanho v�lido em horas (n�mero inteiro positivo)." << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	unsigned int weeklyhourlimit; //number of hours the driver can work per day
	cout << "Qual o n�mero m�ximo de horas que o condutor pode trabalhar por semana?" << endl;

	while (true) {
		cin >> weeklyhourlimit;
		if (cin.fail()) {
			cout << "Input inv�lido, por favor introduza um input v�lido em horas (n�mero inteiro)." << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	unsigned int minresttime; //minimum rest time between shifts (hours)
	cout << "Qual o tempo m�nimo de descanso entre turnos para o condutor?" << endl;

	while (true) {
		cin >> minresttime;
		if (cin.fail()) {
			cout << "N�mero de horas de descanso inv�lido, por favor introduza um input v�lido em horas (n�mero inteiro)." << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}


	//Using emplace to avoid unnecessary copy or move operations by calling the constructor in place (where the element will be inserted)
	//Arguments are forwarded to the object constructor
	//shifts vector is added as empty
	drivers.emplace(piecewise_construct, forward_as_tuple(newID), forward_as_tuple(newID, name, shiftsize, weeklyhourlimit, minresttime, vector<Shift>()));

	//Updating hasUnsavedChanges
	hasUnsavedChanges = true;

	//returning true since the driver was successfully added
	return true;
}

bool BusBoss::modifyLine(unsigned int choice, int IDtomodify) {

	switch (choice) {
	case 1:
	{
		//Changing bus frequency
		unsigned int newFreq;
		cout << "Qual a nova frequ�ncia de passagem de autocarros nas linhas (em minutos)? ";
		while (true) {
			cin >> newFreq;
			if (cin.fail()) {
				cout << "Frequ�ncia inv�lida, por favor introduza um n�mero v�lido (inteiro positivo)." << endl;
				//Clearing error flag and cin buffer
				cin.clear();
				cin.ignore(100000, '\n');
			}
			else {
				//if cin didn't fail we have a good input so we break the loop
				break;
			}
		}
		//Changing frequency
		lines[IDtomodify].setFrequency(newFreq);
		break;
	}
	case 2:
	{
		//Changing the list of stops - only altering one stop at a time because otherwise the delay vector is no longer correct relative to the stops
		unsigned int posToChange;
		string newStopName = "";

		//Getting stops vector
		vector<string> stops = lines[IDtomodify].getStops();

		cout << "Qual a paragem a alterar?" << endl;
		//Printing options
		Utilities::printVector(stops);
		cout << ">> ";
		while (true) {
			cin >> posToChange;
			if (cin.fail() || posToChange >= stops.size()) {
				//Clearing error flag and cin buffer
				cin.clear();
				cin.ignore(100000, '\n');
				//Clearing screen and reprinting with warning
				Utilities::clearScreen();
				cout << "Op��o inv�lida, por favor introduza um n�mero v�lido (inteiro positivo menor que " << stops.size() - 1 << ")." << endl;
				cout << "Qual a paragem a alterar?" << endl;
				//Printing options
				Utilities::printVector(stops);
				cout << ">> ";
			}
			else {
				//if cin didn't fail and the input is a good position we have a good input so we break the loop
				break;
			}
		}

		//Now asking for the new name
		cout << "Qual o novo nome para a paragem a alterar?" << endl;
		cout << ">> ";
		//With the testing done, this is needed if we are to use getline after using cin as a stream
		cin.ignore(10000, '\n');
		getline(cin, newStopName); //using getline instead of cin because a stop name can have spaces
		Utilities::trimString(newStopName); //trimming unnecessary whitespace

		//Changing the stop name in local vector
		stops[posToChange] = newStopName;

		//Changing the line object
		lines[IDtomodify].setStops(stops);

		break;
	}
	case 3:
	{
		//Changing the list of travel delays - only altering one delay at a time because otherwise the delay vector is no longer correct relative to the stops
		unsigned int posToChange;
		unsigned int newDelay = 0;

		//Getting times vector
		vector<unsigned int> times = lines[IDtomodify].getTravelTimesBetweenStops();
		//Getting stops vector
		vector<string> stops = lines[IDtomodify].getStops();

		cout << "Qual o tempo de viagem a alterar?" << endl;
		//Printing options
		for (int i = 0; i < stops.size() - 1; i++) {
			cout << i << ": " << "Tempo de viagem entre " << stops[i] << " e " << stops[i + 1] << ": " << times[i] << " minutos." << endl;
		}
		cout << ">> ";

		while (true) {
			cin >> posToChange;
			if (cin.fail() || posToChange >= times.size()) {
				//Clearing error flag and cin buffer
				cin.clear();
				cin.ignore(100000, '\n');
				//Clearing screen and reprinting with warning
				Utilities::clearScreen();
				cout << "Op��o inv�lida, por favor introduza um n�mero v�lido (inteiro positivo menor que " << times.size() - 1 << ")." << endl;
				cout << "Qual o tempo de viagem a alterar?" << endl;
				//Printing options
				for (int i = 0; i < stops.size() - 1; i++) {
					cout << i << ": " << "Tempo de viagem entre " << stops[i] << " e " << stops[i + 1] << ": " << times[i] << " minutos." << endl;
				}
				cout << ">> ";
			}
			else {
				//if cin didn't fail and the input is a good position we have a good input so we break the loop
				break;
			}
		}

		//Now asking for the new delay
		cout << "Qual o novo tempo de viagem (em minutos)? ";
		while (true) {
			cin >> newDelay;
			if (cin.fail()) {
				cout << "Tempo de viagem inv�lido, por favor introduza um tempo v�lido (n�mero inteiro positivo)." << endl;
				//Clearing error flag and cin buffer
				cin.clear();
				cin.ignore(100000, '\n');
			}
			else {
				//if cin didn't fail we have a good input so we break the loop
				break;
			}
		}

		//Changing time vector locally
		times[posToChange] = newDelay;

		//Changing times in object
		lines[IDtomodify].setTravelTimesBetweenStops(times);

		break;
	}
	default:
		//The choice should never be invalid but if it is return false (error has ocurred)
		return false;
		break;
	}

	return true;
}

bool BusBoss::modifyDriver() {
	int IDtomodify;

	cout << "Qual o ID do condutor a alterar? ";
	while (true) {
		cin >> IDtomodify;
		if (cin.fail()) {
			cout << "ID inv�lido, por favor introduza um ID v�lido (n�mero inteiro)." << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	//Checking if a driver with the given ID exists (number of elements bigger than 0)
	//Because we are using a map and not multimap .count will always be either 0 or 1 but > 0 is used for clarity
	bool driverExists = (drivers.count(IDtomodify) > 0);
	if (!driverExists) {
		cout << "O ID dado n�o corresponde a nenhum dos condutores guardados.\nAbortando o processo de modifica��o de condutor..." << endl;
		return false;
	}

	//Clearing screen
	Utilities::clearScreen();

	cout << "Condutor encontrado." << endl;
	cout << "Qual das informa��es do condutor quer alterar? (Ctrl + Z para abortar o processo)" << endl;

	unsigned int choice = 0; //holds the user selection of the attribute to modify

	cout << "1 - Nome\n";
	cout << "2 - Tamanho de turno em horas\n";
	cout << "3 - Limite de horas de trabalho semanal\n";
	cout << "4 - Tempo m�nimo de descanso entre turnos\n";
	cout << ">> ";

	//This also has to be outside the loop to make sure that the check is ran before the function crashes
	if (cin.eof()) {
		cin.clear();
		cin.ignore(10000, '\n');
		cout << "EOF detetado, abortando processo de modifica��o de condutor..." << endl;
		return false;
	}

	//Ask for choice again if it was invalid
	while (true) {
		cin >> choice;
		if (choice >= 1 && choice <= 4) {
			//if the choice is between 1 and 4 the input is valid so the loop is exited
			break;
		}
		else {
			if (cin.eof()) {
				cin.clear();
				cin.ignore(10000, '\n');
				cout << "EOF detetado, abortando processo de modifica��o de linha..." << endl;
				return false;
			}
			else {
				//Due to choice out of bounds or cin.fail()

				//Clearing screen before re-printing
				Utilities::clearScreen();
				cout << "Escolha inv�lida, por favor introduza uma op��o v�lida (n�mero inteiro entre 1 e 4)." << endl;
				cout << "Qual das informa��es do condutor quer alterar? (Ctrl + Z para abortar o processo)" << endl;
				cout << "1 - Nome\n";
				cout << "2 - Tamanho de turno em horas\n";
				cout << "3 - Limite de horas de trabalho semanal\n";
				cout << "4 - Tempo m�nimo de descanso entre turnos\n";
				cout << ">> ";
				//Clearing error flag and cin buffer in case that this was due to cin.fail() - if it wasn't this has no effect so there is no problem in doing it like this
				cin.clear();
				cin.ignore(100000, '\n');
			}
		}
	}

	//Calling modifier function based on choice
	modifyDriver(choice, IDtomodify);

	//Updating hasUnsavedChanges
	hasUnsavedChanges = true;

	//process was concluded successfully, returning true
	return true;
}

bool BusBoss::modifyDriver(unsigned int choice, int IDtomodify) {

	switch (choice) {
	case 1:
	{
		//Changing driver name
		string newName;
		cout << "Qual o novo nome do condutor? ";
		//With the testing done, this is needed if we are to use getline after using cin as a stream
		cin.ignore(10000, '\n');
		getline(cin, newName);

		//Changing name
		drivers[IDtomodify].setName(newName);
		break;
	}
	case 2:
	{
		//Changing the shift size
		unsigned int newShiftSize;

		cout << "Qual o novo tamanho de turno (em horas)? ";
		while (true) {
			cin >> newShiftSize;
			if (cin.fail()) {
				cout << "Tamanho de turno inv�lido, por favor introduza um n�mero v�lido (inteiro positivo)." << endl;
				//Clearing error flag and cin buffer
				cin.clear();
				cin.ignore(100000, '\n');
			}
			else {
				//if cin didn't fail we have a good input so we break the loop
				break;
			}
		}

		//Changing shiftsize
		drivers[IDtomodify].setShiftSize(newShiftSize);
		break;
	}
	case 3:
	{
		//Changing the number of hours the driver can work per week
		unsigned int newWeeklyhourlimit;

		cout << "Qual o novo limite de horas de trabalho semanal? ";
		while (true) {
			cin >> newWeeklyhourlimit;
			if (cin.fail()) {
				cout << "Limite inv�lido, por favor introduza um n�mero v�lido (inteiro positivo)." << endl;
				//Clearing error flag and cin buffer
				cin.clear();
				cin.ignore(100000, '\n');
			}
			else {
				//if cin didn't fail we have a good input so we break the loop
				break;
			}
		}

		//Changing weeklyhourlimit
		drivers[IDtomodify].setWeeklyHourLimit(newWeeklyhourlimit);
		break;
	}
	case 4:
	{
		//Changing the minimum rest time between shifts (hours)
		unsigned int newMinresttime;

		cout << "Qual o novo tempo m�nimo de descanso entre turnos? ";
		while (true) {
			cin >> newMinresttime;
			if (cin.fail()) {
				cout << "Tempo inv�lido, por favor introduza um n�mero v�lido (inteiro positivo)." << endl;
				//Clearing error flag and cin buffer
				cin.clear();
				cin.ignore(100000, '\n');
			}
			else {
				//if cin didn't fail we have a good input so we break the loop
				break;
			}
		}

		//Changing shiftsize
		drivers[IDtomodify].setMinRestTime(newMinresttime);
		break;
	}
	default:
		//The choice should never be invalid but if it is return false (error has ocurred)
		return false;
		break;
	}

	return true;
}

bool BusBoss::deleteDriver() {
	int IDtodel;
	cout << "Qual o ID do condutor a apagar?" << endl;
	while (true) {
		cin >> IDtodel;
		if (cin.fail()) {
			cout << "ID inv�lido, por favor introduza um ID v�lido (n�mero inteiro)." << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	//Checking if a driver with the given ID exists (number of elements bigger than 0)
	//Because we are using a map and not multimap .count will always be either 0 or 1 but > 0 is used for clarity
	bool driverExists = (drivers.count(IDtodel) > 0);
	if (!driverExists) {
		cout << "O ID dado n�o corresponde a nenhum dos condutores guardados.\nAbortando o processo de elimina��o de condutor..." << endl;
		return false;
	}

	cout << "Condutor encontrado, eliminando..." << endl;
	drivers.erase(IDtodel); //deleting the position of the map results in deleting the driver

	//Updating hasUnsavedChanges
	hasUnsavedChanges = true;

	//process was concluded successfully, returning true
	return true;
}

bool BusBoss::assignShift() {
	unsigned int lineID = 0;

	cout << "Qual o ID da linha para a qual quer efetuar atribui��o de servi�o?" << endl;
	while (true) {
		cin >> lineID;
		if (cin.fail()) {
			cout << "ID inv�lido, por favor introduza um ID v�lido (n�mero inteiro positivo)." << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	//Checking if a line with the given ID exists (number of elements bigger than 0)
	//Because we are using a map and not multimap .count will always be either 0 or 1 but > 0 is used for clarity
	bool lineExists = (lines.count(lineID) > 0);
	if (!lineExists) {
		cout << "O ID dado n�o corresponde a nenhuma das linhas guardadas.\nAbortando o processo de atribui��o interativa de servi�o aos condutores..." << endl;
		return false; //returning false since the process was not concluded successfully
	}

	//Printing already available information
	cout << "Turnos dispon�veis para esta linha:" << endl;
	listBusUnassignedPeriodsByLine(lineID);

	//Spaces
	cout << "\n\n";

	unsigned int desiredWeekday = 0; //weekdays as according to Utilities::weekdays, [0,6]

	cout << "Qual o dia da semana para o qual quer efetuar atribui��o de servi�o?" << endl;
	Utilities::printVector(Utilities::weekdays);
	while (true) {
		cin >> desiredWeekday;
		if (cin.fail() || (desiredWeekday > 6 || desiredWeekday < 0)) {
			//Clearing screen
			Utilities::clearScreen();
			//Displaying error message and repeating input asking
			cout << "Dia da semana inv�lido, por favor introduza um dia da semana v�lido (n�mero inteiro positivo entre 0 e 6)." << endl;
			cout << "Qual o dia da semana para o qual quer efetuar atribui��o de servi�o?" << endl;
			Utilities::printVector(Utilities::weekdays);
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	//Clearing screen
	Utilities::clearScreen();

	//Printing available shifts with the information given
	cout << "Turnos dispon�veis para a linha " << lineID << " e " << Utilities::weekdays[desiredWeekday] << ":" << endl;
	listBusUnassignedPeriodsByLineAndWeekday(lineID, desiredWeekday);

	//Spaces
	cout << "\n\n";

	unsigned int maxOrderNumber = lines[lineID].getNrOfBuses();
	unsigned int selectedBus = 0;

	cout << "Em qual autocarro � que quer atribuir o servi�o? (N�mero entre 1 e " << maxOrderNumber << ")" << endl;
	while (true) {
		cin >> selectedBus;
		if (cin.fail() || (selectedBus < 1 || selectedBus > maxOrderNumber)) {
			cout << "N�mero de ordem inv�lido, por favor introduza um n�mero de ordem v�lido (n�mero inteiro positivo entre 1 e " << maxOrderNumber << ")" << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	//Printing the available shifts once again, and getting the matching shifts from the function to make sure the user selects a valid one
	cout << "Turnos dispon�veis para a linha " << lineID << ", " << Utilities::weekdays[desiredWeekday] << " e no autocarro n� " << selectedBus << ":" << endl << endl;
	vector<Shift> possibleShifts = listBusUnassignedPeriodsByLineWeekdayAndBusOrderNumber(lineID, desiredWeekday, selectedBus);

	//If there are no possible shifts, then no work can be assigned
	if (possibleShifts.empty()) {
		cout << "Como tal, o processo de atribui��o interativa de turnos ser� abortado..." << endl;
		cout << "Abortando o processo de atribui��o interativa de servi�o aos condutores..." << endl;
		return false;
	}

	//Asking for the shifts to assign (to check if they exist in the selected bus and etc)

	string startTimeStr, endTimeStr;

	cout << "Qual a hora de in�cio do turno a atribuir? (Apresentar sobre o formato HH:MM)" << endl;
	while (true) {
		cin >> startTimeStr;
		//If the input fails or there is not exactly one ':' in the string - other things don't matter, 
		if (cin.fail() || Utilities::countCharInString(startTimeStr, ':') != 1) {
			cout << "Hora num formato inv�lido, por favor tente novamente. (Formato : HH:MM)" << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	//Space
	cout << endl;

	cout << "Qual a hora de fim do turno a atribuir? (Apresentar sobre o formato HH:MM)" << endl;
	while (true) {
		cin >> endTimeStr;
		//If the input fails or there is not exactly one ':' in the string - other things don't matter, 
		if (cin.fail() || Utilities::countCharInString(startTimeStr, ':') != 1) {
			cout << "Hora num formato inv�lido, por favor tente novamente. (Formato : HH:MM)" << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	//Converting time strings to minute ints (+weekday * 1440 because a day has 1440 minutes and we are using a linear time scale)
	unsigned int startTimeMin = Utilities::HHMMtoMinutes(startTimeStr) + desiredWeekday * 1440;
	unsigned int endTimeMin = Utilities::HHMMtoMinutes(endTimeStr) + desiredWeekday * 1440;

	//Finding if this shift can fit in the available shifts (possibleShifts is always sorted because it is kept sorted when modified and created in Bus)
	bool canFit = canFitInShiftInterval(startTimeMin, endTimeMin, possibleShifts);

	if (!canFit) {
		cout << "O intervalo de tempo dado n�o est� contido no conjunto de turnos dispon�veis para atribui��o." << endl;
		cout << "Abortando o processo de atribui��o interativa de servi�o aos condutores..." << endl;
		return false;
	}

	//Spaceee
	cout << endl << endl;

	//Getting the driver to which the shift will be assigned

	unsigned int driverID = 0;

	cout << "Qual o ID do condutor ao qual o turno ser� atribu�do?" << endl;
	while (true) {
		cin >> driverID;
		if (cin.fail()) {
			cout << "ID inv�lido, por favor introduza um ID v�lido (n�mero inteiro)." << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	//Checking if a driver with the given ID exists (number of elements bigger than 0)
	//Because we are using a map and not multimap .count will always be either 0 or 1 but > 0 is used for clarity
	bool driverExists = (drivers.count(driverID) > 0);
	if (!driverExists) {
		cout << "O ID dado n�o corresponde a nenhum dos condutores guardados.\nAbortando o processo de atribui��o interativa de servi�o aos condutores..." << endl;
		return false;
	}

	//Clearing screen
	Utilities::clearScreen();

	cout << "Condutor encontrado, testando se o turno pedido lhe poder� ser atribu�do..." << endl << endl;

	//Creating shift object that will be assigned to driver (with previous testing to make sure it can be assigned
	Shift newShift(lineID, driverID, selectedBus, startTimeMin, endTimeMin);

	//Testing if the driver can be assigned the given shift
	unsigned int driverAssignReturn = drivers[driverID].addShift(newShift);

	////addShift return values:
	/*
	0: Process possible, everything normal and the shift was added to the driver
	1: Max weekly hours were reached or will be overcome with this shift
	2: Time since last shift and until the next shift is >= than the minimum rest time
	3: Shift size is larger than the maximum shift size
	other: unexpected behaviour (as in not coded for now and should never happen because the returns are specific values, but just in case)
	*/

	if (driverAssignReturn == 0) {

		//Removing the now assigned work from the bus
		lines[lineID].removeWork(selectedBus, startTimeMin, endTimeMin);

		cout << "Turno atribu�do com sucesso ao condutor, e turno ocupado no autocarro selecionado." << endl;

		//Process concluded successfully
		return true;
	}
	else if (driverAssignReturn == 1) {

		cout << "O n�mero de horas m�ximas de trabalho semanal para este condutor foi atingido ou ser� atingido com a adi��o deste turno." << endl;
		cout << "O turno n�o foi, portanto, adicionado." << endl;
		cout << "Processo de atribui��o interativa de servi�o aos condutores conclu�do sem sucesso..." << endl;

		//Process was unsuccessful
		return false;
	}
	else if (driverAssignReturn == 2) {
		cout << "O tempo entre turnos n�o respeita o n�mero m�nimo de horas de descanso do condutor se este turno fosse adicionado." << endl;
		cout << "O turno n�o foi, portanto, adicionado." << endl;
		cout << "Processo de atribui��o interativa de servi�o aos condutores conclu�do sem sucesso..." << endl;

		//Process was unsuccessful
		return false;
	}
	else if (driverAssignReturn == 3) {
		cout << "O tamanho do turno � maior do que o tamanho m�ximo do turno para este condutor." << endl;
		cout << "O turno n�o foi, portanto, adicionado." << endl;
		cout << "Processo de atribui��o interativa de servi�o aos condutores conclu�do sem sucesso..." << endl;

		//Process was unsuccessful
		return false;
	}
	else {
		cout << "Comportamento n�o previsto, por favor contacte o seu fornecedor de software." << endl;
		cout << "O turno n�o foi, portanto, adicionado." << endl;
		cout << "Processo de atribui��o interativa de servi�o aos condutores conclu�do sem sucesso..." << endl;

		//Process was unsuccessful
		return false;
	}


}

void BusBoss::displayDrivers() {

	//for that goes through all elements of map aka all drivers
	for (auto const &it : drivers) {
		//.second gets data, .first is key
		cout << "ID: " << it.second.getID() << " Nome: " << it.second.getName() << endl;
	}

}

void BusBoss::displayDrivers(bool availability) {
	//Using range based for loop to iterate throught the drivers map
	for (auto const &it : drivers) {
		//If the driver has the same availability as the one given as parameters, then print
		if (it.second.isAvailable() == availability) {
			cout << "ID: " << it.second.getID() << " Nome: " << it.second.getName() << endl;
		}
	}
}

void BusBoss::displayLines() {

	//for to go through all elements of map aka all lines
	for (auto const &it : lines) {
		//.second gets data, .first is key

		cout << "ID: " << it.second.getID() << " Primeira e �ltima paragem: ";
		cout << it.second.getFirstStop() << " ... " << it.second.getLastStop();
		cout << endl;
	}

}

bool BusBoss::printDriver() {
	unsigned int IDtoprint = 0;

	cout << "Qual o ID do condutor a imprimir?" << endl;
	while (true) {
		cin >> IDtoprint;
		if (cin.fail()) {
			cout << "ID inv�lido, por favor introduza um ID v�lido (n�mero inteiro positivo)." << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	//Checking if a driver with the given ID exists (number of elements bigger than 0)
	//Because we are using a map and not multimap .count will always be either 0 or 1 but > 0 is used for clarity
	bool driverExists = (drivers.count(IDtoprint) > 0);
	if (!driverExists) {
		cout << "O ID dado n�o corresponde a nenhum dos condutores guardados.\nAbortando o processo de impress�o de informa��o detalhada de um condutor..." << endl;
		return false;
	}

	//Driver found, printing detailed info
	cout << "\n";
	cout << drivers[IDtoprint];

	//Process concluded successfully
	return true;
}

bool BusBoss::printLine() {
	unsigned int IDtoprint = 0;

	cout << "Qual o ID da linha a imprimir?" << endl;
	while (true) {
		cin >> IDtoprint;
		if (cin.fail()) {
			cout << "ID inv�lido, por favor introduza um ID v�lido (n�mero inteiro positivo)." << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	//Checking if a line with the given ID exists (number of elements bigger than 0)
	//Because we are using a map and not multimap .count will always be either 0 or 1 but > 0 is used for clarity
	bool lineExists = (lines.count(IDtoprint) > 0);
	if (!lineExists) {
		cout << "O ID dado n�o corresponde a nenhuma das linhas guardadas.\nAbortando o processo de impress�o de informa��o detalhada de uma linha..." << endl;
		return false; //returning false since the process was not concluded successfully
	}

	//Line found, printing detailed info
	cout << "\n";
	cout << lines[IDtoprint];

	//Process concluded successfully
	return true;
}

bool BusBoss::printDriverShifts() {
	unsigned int IDtoprint = 0;

	cout << "Qual o ID do condutor para o qual se ir� imprimir o trabalho atribu�do?" << endl;
	while (true) {
		cin >> IDtoprint;
		if (cin.fail()) {
			cout << "ID inv�lido, por favor introduza um ID v�lido (n�mero inteiro positivo)." << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	//Checking if a driver with the given ID exists (number of elements bigger than 0)
	//Because we are using a map and not multimap .count will always be either 0 or 1 but > 0 is used for clarity
	bool driverExists = (drivers.count(IDtoprint) > 0);
	if (!driverExists) {
		cout << "O ID dado n�o corresponde a nenhum dos condutores guardados.\nAbortando o processo de impress�o de informa��o detalhada de um condutor..." << endl;
		return false;
	}

	//Clearing screen for output
	Utilities::clearScreen();

	//Driver found, printing shifts
	//Space
	cout << "\n";
	//Print
	printDriverShifts(IDtoprint);

	//Process concluded successfully
	return true;
}

bool BusBoss::printBusInfo() {
	unsigned int lineID = 0;

	cout << "Qual o ID da linha a imprimir?" << endl;
	while (true) {
		cin >> lineID;
		if (cin.fail()) {
			cout << "ID inv�lido, por favor introduza um ID v�lido (n�mero inteiro positivo)." << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	//Checking if a line with the given ID exists (number of elements bigger than 0)
	//Because we are using a map and not multimap .count will always be either 0 or 1 but > 0 is used for clarity
	bool lineExists = (lines.count(lineID) > 0);
	if (!lineExists) {
		cout << "O ID dado n�o corresponde a nenhuma das linhas guardadas.\nAbortando o processo de impress�o de informa��o detalhada de um autocarro..." << endl;
		return false; //returning false since the process was not concluded successfully
	}

	//Line found, asking for bus order number

	unsigned int busOrderNumber = 0;

	cout << "\n";
	cout << "Qual o n�mero de ordem do autocarro a imprimir?";
	while (true) {
		cin >> lineID;
		if (cin.fail()) {
			cout << "N�mero de ordem inv�lido, por favor introduza um n�mero de ordem v�lido (n�mero inteiro positivo)." << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	//Checking if the bus in that order exists

	//Getting bus fleet
	vector<Bus> busFleet = lines[lineID].getBusFleet();

	//Pointer to the found object - const means not that the pointer is constant and will only point to one thing but that the object it points to is constant!
	const Bus *busToPrint = nullptr;

	//for each bus in busFleet
	for (auto const &bus : busFleet) {
		if (bus.getBusOrderInLine() == busOrderNumber) {
			//If the bus is found then the object pointer is set and the loop is broken
			busToPrint = &bus;
			break;
		}
	}

	//If the bus was found, print it, otherwise print error message
	//(If the bus was found then the pointer was set, which means it is not nullptr
	if (busToPrint != nullptr) {
		cout << "Autocarro especificado com sucesso!" << endl;
		cout << "Imprimindo informa��es sobre o autocarro:\n";

		cout << *busToPrint;

		//Process concluded successfully
		return true;
	}
	else {
		cout << "O autocarro com o n�mero de ordem especificado n�o foi encontrado..." << endl;
		cout << "Abortando o processo de impress�o de informa��o sobre um autocarro..." << endl;

		//Process was unsuccessful
		return false;
	}

}

bool BusBoss::listBusesInLine() {
	unsigned int lineID = 0;

	cout << "Qual o ID da linha a imprimir?" << endl;
	while (true) {
		cin >> lineID;
		if (cin.fail()) {
			cout << "ID inv�lido, por favor introduza um ID v�lido (n�mero inteiro positivo)." << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	//Checking if a line with the given ID exists (number of elements bigger than 0)
	//Because we are using a map and not multimap .count will always be either 0 or 1 but > 0 is used for clarity
	bool lineExists = (lines.count(lineID) > 0);
	if (!lineExists) {
		cout << "O ID dado n�o corresponde a nenhuma das linhas guardadas.\nAbortando o processo de impress�o de informa��o detalhada de uma linha..." << endl;
		return false; //returning false since the process was not concluded successfully
	}

	//Line found, printing info of the busFleet

	cout << endl;

	vector<Bus> busFleet = lines[lineID].getBusFleet();

	cout << "A frota da linha pedida tem " << busFleet.size() << " autocarros." << endl;

	for (int i = 0; i < busFleet.size(); ++i) {
		cout << "Informa��o do autocarro n� " << i + 1 << ":" << endl;
		cout << busFleet[i] << endl;
	}

	return true;
}

bool BusBoss::listAllBusUnassignedPeriods() {

	vector<Bus> tempBuses;
	vector<Shift> tempBusRemainingShifts;

	//for each line, we are going to be listing each bus's unassigned period
	for (auto const &line : lines) {

		tempBuses = line.second.getBusFleet();

		cout << "Linha " << line.second.getID() << ":" << endl;

		//for each bus in the line
		for (auto const &bus : tempBuses) {
			cout << "Autocarro n� " << bus.getBusOrderInLine() << " de " << tempBuses.size() << ":" << endl;
			tempBusRemainingShifts = bus.getRemainingWork();

			if (tempBusRemainingShifts.empty()) {
				cout << "Este autocarro j� tem todo o seu trabalho atribu�do." << endl;
			}
			else {
				cout << "Trabalho que ainda falta atribuir condutor a:" << endl;

				//for each remaining shift in the bus - printing the times that are missing a driver
				for (auto const &shift : tempBusRemainingShifts) {
					auto startTime = Utilities::minutesToTime(shift.getStartTime());
					auto endTime = Utilities::minutesToTime(shift.getEndTime());
					cout << "In�cio do turno: " << startTime << "\t";
					cout << "Fim do turno: " << endTime << endl;
				}
			}
		}

	}

	cout << endl;

	//Process was concluded successfully
	return true;
}

bool BusBoss::listBusUnassignedPeriodsByLine() {
	unsigned int lineID = 0;

	cout << "Qual o ID da linha cujos per�odos de trabalho dispon�veis nos autocarros se ir� imprimir?" << endl;
	while (true) {
		cin >> lineID;
		if (cin.fail()) {
			cout << "ID inv�lido, por favor introduza um ID v�lido (n�mero inteiro positivo)." << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	//Checking if a line with the given ID exists (number of elements bigger than 0)
	//Because we are using a map and not multimap .count will always be either 0 or 1 but > 0 is used for clarity
	bool lineExists = (lines.count(lineID) > 0);
	if (!lineExists) {
		cout << "O ID dado n�o corresponde a nenhuma das linhas guardadas.\nAbortando o processo de impress�o de per�odos de trabalho dispon�veis nos autocarros de uma linha..." << endl;
		return false; //returning false since the process was not concluded successfully
	}

	//Printing based on given lineID
	listBusUnassignedPeriodsByLine(lineID);

	//Process concluded successfully
	return true;
}

bool BusBoss::listBusUnassignedPeriodsByLineAndWeekday() {
	unsigned int lineID = 0;

	cout << "Qual o ID da linha cujos per�odos de trabalho dispon�veis nos autocarros se ir� imprimir?" << endl;
	while (true) {
		cin >> lineID;
		if (cin.fail()) {
			cout << "ID inv�lido, por favor introduza um ID v�lido (n�mero inteiro positivo)." << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	//Checking if a line with the given ID exists (number of elements bigger than 0)
	//Because we are using a map and not multimap .count will always be either 0 or 1 but > 0 is used for clarity
	bool lineExists = (lines.count(lineID) > 0);
	if (!lineExists) {
		cout << "O ID dado n�o corresponde a nenhuma das linhas guardadas.\nAbortando o processo de impress�o de per�odos de trabalho dispon�veis nos autocarros de uma linha..." << endl;
		return false; //returning false since the process was not concluded successfully
	}

	unsigned int desiredWeekday = 0; //weekdays as according to Utilities::weekdays, [0,6]

	cout << "Qual o dia da semana para o qual mostrar os turnos dispon�veis?" << endl;
	Utilities::printVector(Utilities::weekdays);
	while (true) {
		cin >> desiredWeekday;
		if (cin.fail() || (desiredWeekday > 6 || desiredWeekday < 0)) {
			//Clearing screen
			Utilities::clearScreen();
			//Displaying error message and repeating input asking
			cout << "Dia da semana inv�lido, por favor introduza um dia da semana v�lido (n�mero inteiro positivo entre 0 e 6)." << endl;
			cout << "Qual o dia da semana para o qual mostrar os turnos dispon�veis?" << endl;
			Utilities::printVector(Utilities::weekdays);
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	//Printing based on user input
	listBusUnassignedPeriodsByLineAndWeekday(lineID, desiredWeekday);

	//Process concluded successfully
	return true;
}

bool BusBoss::listDriverUnassignedPeriods() {
	Utilities::clearScreen();

	cout << "Ser�o impressos todos os turnos de todos os condutores dispon�veis, que ser�o os per�odos de tempo em que estes est�o ocupados." << endl;
	cout << "Durante todo o restante tempo, estes est�o dispon�veis." << endl;

	//Space
	cout << "\n\n";

	for (const auto &driver : drivers)	{
		//Printing only the available drivers
		if (driver.second.isAvailable()) {

			//Printing identifying info - ID and Name
			cout << "Condutor com ID " << driver.second.getID() << " e nome " << driver.second.getName() << ":" << endl;
			//Printing shifts
			printDriverShifts(driver.second.getID());
			//Space between drivers
			cout << endl;
		}
	}

	//Process concluded successfully
	return true;
}

bool BusBoss::Load() {

	//Check to see if the user has unsaved changes before loading a new file
	if (getIfHasUnsavedChanges()) {
		string option;
		cout << "Tem altera��es n�o gravadas, deseja prosseguir com o carregamento de um novo ficheiro? (S/N)" << endl;
		cout << ">> ";
		while (true) {
			cin >> option;
			if (cin.fail() || (option != "S" && option != "N")) {
				//Clearing error flags and buffer
				cin.clear();
				cin.ignore(10000, '\n');
				//Clearing screen to display input prompt again
				cout << "Op��o inv�lida." << endl;
				cout << "Tem altera��es n�o gravadas, deseja prosseguir com o carregamento de um novo ficheiro? (S/N)" << endl;
				cout << ">> ";
			}
			else {
				//input is valid so we break the loop
				break;
			}
		}

		//If the user specifies that he does not want to continue because he has unsaved progress we quit the file loading
		if (option == "N") {
			cout << "Abortando processo de carregamento de ficheiros..." << endl;
			return false;
		}
		else {
			//Otherwise, the user specified that he does want to continue so we simply clear the screen to make space for the following output
			Utilities::clearScreen();
		}
	}

	ifstream inputDrivers, inputLines;
	//string for the path for the drivers and lines files. Separate variables are used to be able to save the path to internal variables if the process is not aborted
	string  inputpathDrivers = "", inputpathLines = "";

	//Clearing the cin stream - might get unwanted input in if not cleared before using getline
	//If there are more than 0 characters in the cin buffer, clear them, otherwise getline will get that input
	if (cin.rdbuf()->in_avail() > 0) {
		cin.ignore(10000, '\n');
	}

	//Drivers file input
	cout << "Insira o nome do ficheiro a usar para os condutores: (exemplo: \"condutores_test.txt\")" << endl;
	cout << "(Ctrl+Z para abortar o processo - a informa��o interna estar� vazia e a maior parte das funcionalidades n�o ir�o funcionar corretamente)" << endl;
	cout << ">> ";
	//Using getline because the path can contain spaces
	getline(cin, inputpathDrivers);

	//This also has to be outside the loop to make sure that the check is ran before the function crashes
	//It seems to not be possible to avoid having to press enter twice for this to work, must be because getline needs an enter and then cin.eof wants cin to be populated and so requires another enter
	if (cin.eof()) {
		cin.clear();
		cin.ignore(10000, '\n');
		cout << "EOF detetado, abortando processo de cria��o de gestor de empresa de autocarros..." << endl;
		return false;
	}

	//Opening the file with the given path
	inputDrivers.open(inputpathDrivers);

	//Testing if the path was invalid
	while (!inputDrivers.is_open()) {
		//Clears screen before re-writing
		Utilities::clearScreen();
		cout << "Nome do ficheiro inv�lido!" << endl;
		cout << "Insira o nome do ficheiro a usar para os condutores: (exemplo: \"condutores_test.txt\")" << endl;
		cout << "(Ctrl+Z para abortar o processo - a informa��o interna estar� vazia e a maior parte das funcionalidades n�o ir�o funcionar corretamente)" << endl;
		cout << ">> ";
		getline(cin, inputpathDrivers);
		if (cin.eof()) {
			cin.clear();
			cin.ignore(10000, '\n');
			cout << "EOF detetado, abortando processo de cria��o de gestor de empresa de autocarros..." << endl;
			return false;
		}
		else
			inputDrivers.open(inputpathDrivers);
	}

	//Success
	cout << "\nFicheiro de condutores aberto com sucesso!\n\n\n";

	//Lines file input - same idea as above
	cout << "Insira o nome do ficheiro a usar para as linhas: (exemplo: \"linhas_test.txt\")" << endl;
	cout << "(Ctrl+Z para abortar o processo - a informa��o interna estar� vazia e a maior parte das funcionalidades n�o ir�o funcionar corretamente)" << endl;
	cout << ">> ";
	//Using getline because the path can contain spaces
	getline(cin, inputpathLines);

	//This also has to be outside the loop to make sure that the check is ran before the function crashes
	if (cin.eof()) {
		cin.clear();
		cin.ignore(10000, '\n');
		cout << "EOF detetado, abortando processo de cria��o de gestor de empresa de autocarros..." << endl;
		return false;
	}


	//Opening the file with the given path
	inputLines.open(inputpathLines);

	//Testing if the path was invalid
	while (!inputLines.is_open()) {
		//Clears screen before re-writing
		Utilities::clearScreen();
		cout << "Nome do ficheiro inv�lido!" << endl;
		cout << "Insira o nome do ficheiro a usar para as linhas: (exemplo: \"linhas_test.txt\")" << endl;
		cout << "(Ctrl+Z para abortar o processo - a informa��o interna estar� vazia e a maior parte das funcionalidades n�o ir�o funcionar corretamente)" << endl;
		cout << ">> ";
		getline(cin, inputpathLines);
		if (cin.eof()) {
			cin.clear();
			cin.ignore(10000, '\n');
			cout << "EOF detetado, abortando processo de cria��o de gestor de empresa de autocarros..." << endl;
			return false;
		}
		inputLines.open(inputpathLines);
	}

	//Success
	cout << "\nFicheiro de linhas aberto com sucesso!\n\n\n";

	//Both files were opened successfully, resetting internal data to replace it with new one:
	//Internal data is reset. For the first load this does nothing but for the next ones this will clear internal data (drivers, lines, etc)
	Reset();

	//From now on the files are loaded into memory so it is safe to save the path from which they were gotten
	this->driversFilePath = inputpathDrivers;
	this->linesFilePath = inputpathLines;
	//The save is only done now because if the process was aborted before this the internal memory would be unchanged and thus still linked to the file that was opened before

	//Updating hasUnsavedChanges - if we are loading from a file we do not have unsaved changes
	hasUnsavedChanges = false;

	//Passing the contents of the text files to a string vector where each index is a line in the file
	vector<string> RawDrivers = Utilities::ReadFile(inputDrivers);
	vector<string> RawLines = Utilities::ReadFile(inputLines);

	//Closing ifstreams
	inputDrivers.close();
	inputLines.close();

	//Populating data structures

	string rawtempid = "";
	//Populating drivers map
	for (int i = 0; i < RawDrivers.size(); i++) {
		//Getting the raw id string to use when creating the map element
		rawtempid = RawDrivers[i].substr(0, RawDrivers[i].find(";"));
		//Trimming the string to remove unnecessary spaces
		Utilities::trimString(rawtempid);

		//Using emplace to avoid unnecessary copy or move operations by calling the constructor in place (where the element will be inserted)
		drivers.emplace(piecewise_construct, forward_as_tuple(stoi(rawtempid)), forward_as_tuple(RawDrivers[i]));
	}

	rawtempid = "";
	//Populating lines map
	for (int i = 0; i < RawLines.size(); i++) {
		//Getting the raw id string to use when creating the map element
		rawtempid = RawLines[i].substr(0, RawLines[i].find(";"));
		//Trimming the string to remove unnecessary spaces
		Utilities::trimString(rawtempid);

		//Using emplace to avoid unnecessary copy or move operations by calling the constructor in place (where the element will be inserted)
		lines.emplace(piecewise_construct, forward_as_tuple(stoi(rawtempid)), forward_as_tuple(RawLines[i]));
	}

	//Sorting drivers into lines
	//sortData();
	//distributeDrivers();
	//etc

	//After everything was successful
	return true;
}

bool BusBoss::Save() {
	//File output streams
	ofstream outputDrivers, outputLines;

	//temporary variables for file path in case the internal variables do not work - they start as the internal paths because if the paths open straight away they are not changed so the internal vars are not reset accidentally
	string tempLinesFilePath = linesFilePath, tempDriversFilePath = driversFilePath;

	//Attempting to open files
	outputDrivers.open(driversFilePath);
	outputLines.open(linesFilePath);

	if (!outputDrivers.is_open()) {

		//Clearing the cin stream - might get unwanted input in if not cleared before using getline
		//If there are more than 0 characters in the cin buffer, clear them, otherwise getline will get that input
		if (cin.rdbuf()->in_avail() > 0) {
			cin.ignore(10000, '\n');
		}

		cout << "Ainda n�o foi carregada informa��o de um ficheiro de condutores ou o ficheiro j� n�o existe." << endl;
		cout << "Por favor introduza o nome do ficheiro a usar para guardar os condutores: (exemplo: \"condutores_test.txt\")" << endl;
		cout << "(Ctrl+Z para abortar o processo - a informa��o interna n�o ser� gravada)" << endl;
		cout << ">> ";

		//Using getline because the path can contain spaces
		getline(cin, tempDriversFilePath);

		//This also has to be outside the loop to make sure that the check is ran before the function crashes
		//It seems to not be possible to avoid having to press enter twice for this to work, must be because getline needs an enter and then cin.eof wants cin to be populated and so requires another enter
		if (cin.eof()) {
			cin.clear();
			cin.ignore(10000, '\n');
			cout << "EOF detetado, abortando processo de grava��o de ficheiros..." << endl;
			return false;
		}

		//Opening the file with the given path
		outputDrivers.open(tempDriversFilePath);

		//Testing if the path was invalid
		while (!outputDrivers.is_open()) {
			//Clears screen before re-writing
			Utilities::clearScreen();
			cout << "Nome do ficheiro inv�lido!" << endl;
			cout << "Por favor introduza o nome do ficheiro a usar para guardar os condutores: (exemplo: \"condutores_test.txt\")" << endl;
			cout << "(Ctrl+Z para abortar o processo - a informa��o interna n�o ser� gravada)" << endl;
			cout << ">> ";
			getline(cin, tempDriversFilePath);
			if (cin.eof()) {
				cin.clear();
				cin.ignore(10000, '\n');
				cout << "EOF detetado, abortando processo de grava��o de ficheiros..." << endl;
				return false;
			}
			else
				outputDrivers.open(tempDriversFilePath);
		}
	}

	//outputDrivers is ready

	if (!outputLines.is_open()) {
		cout << "Ainda n�o foi carregada informa��o de um ficheiro de linhas ou o ficheiro j� n�o existe." << endl;
		cout << "Por favor introduza o nome do ficheiro a usar para guardar os linhas: (exemplo: \"linhas_test.txt\")" << endl;
		cout << "(Ctrl+Z para abortar o processo - a informa��o interna n�o ser� gravada)" << endl;
		cout << ">> ";

		//Using getline because the path can contain spaces
		getline(cin, tempLinesFilePath);

		//This also has to be outside the loop to make sure that the check is ran before the function crashes
		//It seems to not be possible to avoid having to press enter twice for this to work, must be because getline needs an enter and then cin.eof wants cin to be populated and so requires another enter
		if (cin.eof()) {
			cin.clear();
			cin.ignore(10000, '\n');
			cout << "EOF detetado, abortando processo de grava��o de ficheiros..." << endl;
			return false;
		}

		//Opening the file with the given path
		outputLines.open(tempLinesFilePath);

		//Testing if the path was invalid
		while (!outputLines.is_open()) {
			//Clears screen before re-writing
			Utilities::clearScreen();
			cout << "Nome do ficheiro inv�lido!" << endl;
			cout << "Por favor introduza o nome do ficheiro a usar para guardar os linhas: (exemplo: \"linhas_test.txt\")" << endl;
			cout << "(Ctrl+Z para abortar o processo - a informa��o interna n�o ser� gravada)" << endl;
			cout << ">> ";
			getline(cin, tempLinesFilePath);
			if (cin.eof()) {
				cin.clear();
				cin.ignore(10000, '\n');
				cout << "EOF detetado, abortando processo de grava��o de ficheiros..." << endl;
				return false;
			}
			else
				outputLines.open(tempLinesFilePath);
		}
	}

	//outputLines is ready

	//From now on the process can't aborted so the internal file paths are updated with the new filepaths and hasUnsavedChanges is updated
	driversFilePath = tempDriversFilePath;
	linesFilePath = tempLinesFilePath;
	hasUnsavedChanges = false;

	//Calling save functions
	saveDriverstoFile(outputDrivers);
	saveLinestoFile(outputLines);

	//Closing streams
	outputDrivers.close();
	outputLines.close();

	//Function successful
	cout << "Ficheiros guardados com sucesso." << endl;
	return true;
}

void BusBoss::findLinesinStop() {
	string stopname;

	//Clearing the cin stream - might get unwanted input in if not cleared before using getline
	//If there are more than 0 characters in the cin buffer, clear them, otherwise getline will get that input
	if (cin.rdbuf()->in_avail() > 0) {
		cin.ignore(10000, '\n');
	}

	cout << "Qual a paragem que deseja procurar?" << endl;
	getline(cin, stopname); //getline is used because the stop name can have spaces in it

	//Searching for the stop in lines using findLinesinStop's overload
	vector<unsigned int> foundLines = findLinesinStop(stopname);

	//Outputting result based on foundLines being empty or not
	if (foundLines.empty()) {
		cout << "A paragem dada n�o pertence a nenhuma linha guardada." << endl;
	}
	else {
		cout << "A paragem dada pertence �s seguintes linhas: ";
		cout << foundLines[0];
		for (int i = 1; i < foundLines.size(); i++) {
			cout << ", " << foundLines[i];
		}
		cout << endl;
	}
}

bool BusBoss::routeBetweenTwoStops() {
	//CASES:
	//0: One of them has no lines
	//1: No common lines - we consider only one line change for now, otherwise it is impossible
	//2: One common line - check best direction in the line
	//3: Several common lines - check best direction in each line.. 
	//Ideas - function to check best direction in line

	string stop1, stop2; //variables to hold stop names

	//Clearing the cin stream - might get unwanted input in if not cleared before using getline
	//If there are more than 0 characters in the cin buffer, clear them, otherwise getline will get that input
	if (cin.rdbuf()->in_avail() > 0) {
		cin.ignore(10000, '\n');
	}

	cout << "Qual a paragem de in�cio do percurso?" << endl;
	getline(cin, stop1); //getline is used because the stop name can have spaces in it

	//Checking to which lines stop1 belongs
	vector<unsigned int> foundLinesStop1 = findLinesinStop(stop1);

	//Case 0.1
	if (foundLinesStop1.empty()) {
		cout << "A primeira paragem n�o pertence a nenhuma das linhas guardadas.\nAbortando o processo de c�lculo de percurso entre duas paragens..." << endl;
		return false;
	}

	cout << "Qual a paragem de final do percurso?" << endl;
	getline(cin, stop2); //getline is used because the stop name can have spaces in it

	//Searching for the stop in lines using findLinesinStop
	vector<unsigned int> foundLinesStop2 = findLinesinStop(stop2);

	//Case 0.2
	if (foundLinesStop2.empty()) {
		cout << "A segunda paragem n�o pertence a nenhuma das linhas guardadas.\nAbortando o processo de c�lculo de percurso entre duas paragens..." << endl;
		return false;
	}

	//Case 1
	vector<route> routesSwitch = calculateRouteSwitch(stop1, stop2, foundLinesStop1, foundLinesStop2);

	//Case 2 & 3 - can be handled together due to how things were structured

	//Check lines in common between the two stops
	vector<unsigned int> intersection = Utilities::intersectVectors(foundLinesStop1, foundLinesStop2);

	//Calculating the routes that use the same line
	vector<route> routesSame = calculateRouteSameLine(stop1, stop2, intersection);

	//Joining the routes using same line and 1 line switch
	vector<route> routes = Utilities::joinVectors(routesSwitch, routesSame);

	//Sorting results - comparison function/functor is not necessary since < operator was defined for route
	sort(routes.begin(), routes.end());

	//Printing results

	//Clearing screen
	Utilities::clearScreen();

	//Only print routes if the routes vector isn't empty
	if (!routes.empty()) {

		//"Header"
		cout << "Ponto de Partida: " << stop1 << endl;
		cout << "Destino: " << stop2 << endl;
		cout << "\nCaminhos poss�veis:";


		//Printing results (all available routes)
		for (int i = 0; i < routes.size(); i++) {
			cout << "\n" << i + 1 << ":\n";

			//If there is a line switch we have to print the information differently
			if (routes[i].switchesline) {
				cout << "Apanhar a linha " << routes[i].lineIDs.first << " em dire��o a " << getDirection(routes[i].lineIDs.first, routes[i].directions.first);
				cout << ", durante " << routes[i].nStops.first << (routes[i].nStops.first > 1 ? " paragens." : " paragem.") << endl;
				cout << "Trocar para a linha " << routes[i].lineIDs.second << " em dire��o a " << getDirection(routes[i].lineIDs.second, routes[i].directions.second);
				cout << ", durante " << routes[i].nStops.second << (routes[i].nStops.second > 1 ? " paragens." : " paragem.") << endl;

				cout << "Tempo total de viagem (em minutos): " << routes[i].totalTimeinMinutes << endl;
			}
			else {
				cout << "Apanhar a linha " << routes[i].lineIDs.first << " em dire��o a " << getDirection(routes[i].lineIDs.first, routes[i].directions.first);
				cout << ", durante " << routes[i].nStops.first << (routes[i].nStops.first > 1 ? " paragens." : " paragem.") << endl;

				cout << "Tempo total de viagem (em minutos): " << routes[i].totalTimeinMinutes << endl;
			}
		}
	}
	//If the routes vector is empty no route was found
	else {
		cout << "N�o foi encontrado nenhum percurso poss�vel entre as duas paragens, considerando a possibilidade de 1 transbordo." << endl;
	}


	//Process was successful
	return true;
}

bool BusBoss::getIfHasUnsavedChanges() { return this->hasUnsavedChanges; }
//Refactored but need to improve the display quality really badly...
bool BusBoss::showStopSchedule() {
	string stop;

	//Clearing the cin stream - might get unwanted input in if not cleared before using getline
	//If there are more than 0 characters in the cin buffer, clear them, otherwise getline will get that input
	if (cin.rdbuf()->in_avail() > 0) {
		cin.ignore(10000, '\n');
	}

	cout << "Qual a paragem cujo hor�rio se ir� imprimir?" << endl;
	getline(cin, stop); //getline is used because the stop name can have spaces in it

	//Checking to which lines the given stop belongs
	vector<unsigned int> foundLinesStop = findLinesinStop(stop);

	//Checking if the stop is in no line
	if (foundLinesStop.empty()) {
		cout << "A paragem dada n�o pertence a nenhuma das linhas guardadas.\nAbortando o processo de impress�o de hor�rio para uma paragem..." << endl;
		return false;
	}

	//Getting schedules for the stop given and all the lines it belongs to
	vector<schedule> schedules = generateStopSchedules(stop, foundLinesStop);


	//Variables for inside the loop (preventing redeclaring)
	string direction;
	string fulldirection;
	int spaces, spacesdiv4, middlespace, spacediff;

	cout << "\n\n\n";

	cout << "Hor�rio na paragem " << stop << ":" << "\n\n";

	for (int i = 0; i < schedules.size(); i++) {

		//Positive direction - start to finish

		//If the schedule for this direction is empty it means that the stop is one of the endings in this certain line and thus it makes no sense to display the schedule
		//So, only display it if the schedule isn't empty

		if (!schedules[i].positiveBusTimes.empty()) {

			//Getting the direction
			direction = getDirection(schedules[i].lineID, 1);

			fulldirection = "Sentido em dire��o a " + direction;

			//Spacing definitions
			spaces = fulldirection.length();
			//Fixing the formatting because of uneven divisions
			spacesdiv4 = Utilities::roundToInt((double)spaces / 4);
			spacediff = Utilities::roundToInt((double)spacesdiv4 * 0.2);
			if (spaces % 2 == 0)
				middlespace = spacesdiv4 + 1;
			else
				middlespace = spacesdiv4 + 2;

			//Table formatting with |---|

			//Spacer header top
			cout << "|" << setfill('-') << setw(spaces + 1) << "|" << endl;

			//Line and direction print
			cout << "|" << setfill(' ') << left << setw(spaces) << "Linha " + to_string(schedules[i].lineID) << "|" << endl;
			cout << "|" << setw(spaces) << fulldirection << "|" << endl;

			cout << right;

			//Spacer header bottom
			cout << "|" << setfill('-') << setw(spaces + 1) << "|" << endl;


			//Times print
			for (int j = 0; j < schedules[i].positiveBusTimes.size() - 1; j += 2) {
				cout << setfill(' ') << "|" << setw(spacesdiv4 + spacediff) << schedules[i].positiveBusTimes[j]
					<< setw(middlespace - spacediff) << "!"
					<< setw(spacesdiv4 + spacediff) << schedules[i].positiveBusTimes[j + 1]
					<< setw(spacesdiv4 - spacediff) << "|" << endl;
			}

			//Space between directions
			cout << "\n";
		}

		//Negative direction - finish to start

		//If the schedule for this direction is empty it means that the stop is one of the endings in this certain line and thus it makes no sense to display the schedule
		//So, only display it if the schedule isn't empty

		if (!schedules[i].negativeBusTimes.empty()) {

			//Getting the direction
			direction = getDirection(schedules[i].lineID, -1);

			fulldirection = "Sentido em dire��o a " + direction;

			//Spacing definitions
			spaces = fulldirection.length();
			//Fixing the formatting because of uneven divisions
			spacesdiv4 = Utilities::roundToInt((double)spaces / 4);
			spacediff = Utilities::roundToInt((double)spacesdiv4 * 0.2);
			if (spaces % 2 == 0)
				middlespace = spacesdiv4 + 1;
			else
				middlespace = spacesdiv4 + 2;

			//Table formatting with |---|

			//Spacer header top
			cout << "|" << setfill('-') << setw(spaces + 1) << "|" << endl;

			//Line and direction print
			cout << "|" << setfill(' ') << left << setw(spaces) << "Linha " + to_string(schedules[i].lineID) << "|" << endl;
			cout << "|" << setw(spaces) << fulldirection << "|" << endl;

			cout << right;

			//Spacer header bottom
			cout << "|" << setfill('-') << setw(spaces + 1) << "|" << endl;


			//Times print
			for (int j = 0; j < schedules[i].negativeBusTimes.size() - 1; j += 2) {
				cout << setfill(' ') << "|" << setw(spacesdiv4 + spacediff) << schedules[i].negativeBusTimes[j]
					<< setw(middlespace - spacediff) << "!"
					<< setw(spacesdiv4 + spacediff) << schedules[i].negativeBusTimes[j + 1]
					<< setw(spacesdiv4 - spacediff) << "|" << endl;
			}

			//Spacer between lines
			cout << "\n";
		}


	}

	return true;
}
//(Same as above) Refactored but need to improve the display quality really badly...
bool BusBoss::showLineSchedule() {
	unsigned int lineIDtoprint;

	cout << "Qual o ID da linha cujo hor�rio se ir� imprimir? ";
	while (true) {
		cin >> lineIDtoprint;
		if (cin.fail()) {
			cout << "ID inv�lido, por favor introduza um ID v�lido (n�mero inteiro positivo)." << endl;
			//Clearing error flag and cin buffer
			cin.clear();
			cin.ignore(100000, '\n');
		}
		else {
			//if cin didn't fail we have a good input so we break the loop
			break;
		}
	}

	//Checking if a line with the given ID exists (number of elements bigger than 0)
	//Because we are using a map and not multimap .count will always be either 0 or 1 but > 0 is used for clarity
	bool lineExists = (lines.count(lineIDtoprint) > 0);
	if (!lineExists) {
		cout << "O ID dado n�o corresponde a nenhuma das linhas guardadas.\nAbortando o processo de impress�o do hor�rio de uma linha..." << endl;
		return false; //returning false since the process was not concluded successfully
	}

	//Getting schedules for each stop - each index will be the schedule for the stop in the same index as the stops vector
	vector<schedule> schedules;

	//Getting stops vector to pass each stop into the generateStopSchedules function
	vector<string> stops = lines[lineIDtoprint].getStops();

	//Filling the schedules vector
	for (int i = 0; i < stops.size(); i++) {
		schedules.push_back(generateStopSchedules(stops[i], lineIDtoprint));
	}

	cout << "\n\n\n";

	//Printing schedules

	//Because this is always the same line, the directions are always the same
	string positivedirection = stops[stops.size() - 1]; //Last stop is the positive direction
	string negativedirection = stops[0]; //First stop is the negative direction
	//Note: getDirection could be used as well, but since the vector was already used before, it is needed anyway, so there is no problem in using it here
	string positivefulldirection = "Sentido em dire��o a " + positivedirection;
	string negativefulldirection = "Sentido em dire��o a " + negativedirection;
	// to use inside the loop - preventing redeclaring
	int spaces;
	int spacesdiv4;
	int middlespace;
	int spacediff;

	cout << "Hor�rio para a linha " << lineIDtoprint << ":" << "\n\n";

	for (int i = 0; i < schedules.size(); i++) {

		//Positive direction - start to finish

		//If the schedule for this direction is empty it means that the stop is one of the endings and thus it makes no sense to display the schedule
		//So, only display it if the schedule isn't empty

		if (!schedules[i].positiveBusTimes.empty()) {

			//Spacing definitions
			spaces = positivefulldirection.length();
			//Fixing the formatting because of uneven divisions
			spacesdiv4 = Utilities::roundToInt((double)spaces / 4);
			spacediff = Utilities::roundToInt((double)spacesdiv4 * 0.2);
			if (spaces % 2 == 0)
				middlespace = spacesdiv4 + 1;
			else
				middlespace = spacesdiv4 + 2;


			//Table formatting with |---|

			//Spacer header top
			cout << "|" << setfill('-') << setw(spaces + 1) << "|" << endl;

			//Stop and direction print
			cout << "|" << setfill(' ') << left << setw(spaces) << "Paragem " + stops[i] << "|" << endl;
			cout << "|" << setw(spaces) << positivefulldirection << "|" << endl;

			cout << right;

			//Spacer header bottom
			cout << "|" << setfill('-') << setw(spaces + 1) << "|" << endl;

			//Times print
			for (int j = 0; j < schedules[i].positiveBusTimes.size() - 1; j += 2) {
				cout << setfill(' ') << "|" << setw(spacesdiv4 + spacediff) << schedules[i].positiveBusTimes[j]
					<< setw(middlespace - spacediff) << "!"
					<< setw(spacesdiv4 + spacediff) << schedules[i].positiveBusTimes[j + 1]
					<< setw(spacesdiv4 - spacediff) << "|" << endl;
			}

			//Space between directions
			cout << "\n";
		}

		//Negative direction - finish to start

		//If the schedule for this direction is empty it means that the stop is one of the endings and thus it makes no sense to display the schedule
		//So, only display it if the schedule isn't empty
		if (!schedules[i].negativeBusTimes.empty()) {

			//Spacing definitions
			spaces = negativefulldirection.length();
			//Fixing the formatting because of uneven divisions
			spacesdiv4 = Utilities::roundToInt((double)spaces / 4);
			spacediff = Utilities::roundToInt((double)spacesdiv4 * 0.2);
			if (spaces % 2 == 0)
				middlespace = spacesdiv4 + 1;
			else
				middlespace = spacesdiv4 + 2;

			//Table formatting with |---|

			//Spacer header top
			cout << "|" << setfill('-') << setw(spaces + 1) << "|" << endl;

			//Line and direction print
			cout << "|" << setfill(' ') << left << setw(spaces) << "Paragem " + stops[i] << "|" << endl;
			cout << "|" << setw(spaces) << negativefulldirection << "|" << endl;

			cout << right;

			//Spacer header bottom
			cout << "|" << setfill('-') << setw(spaces + 1) << "|" << endl;


			//Times print
			for (int j = 0; j < schedules[i].negativeBusTimes.size() - 1; j += 2) {
				cout << setfill(' ') << "|" << setw(spacesdiv4 + spacediff) << schedules[i].negativeBusTimes[j]
					<< setw(middlespace - spacediff) << "!"
					<< setw(spacesdiv4 + spacediff) << schedules[i].negativeBusTimes[j + 1]
					<< setw(spacesdiv4 - spacediff) << "|" << endl;
			}


			//Spacer between stops
			cout << "\n";
		}


	}

	return true;
}

unsigned int BusBoss::getStartTime() {
	return BUS_START_TIME_HOUR * 60 + BUS_START_TIME_MINUTE;
}

unsigned int BusBoss::getEndTime() {
	return BUS_END_TIME_HOUR * 60 + BUS_END_TIME_MINUTE;
}

void BusBoss::Reset() {
	//Deleting drivers
	drivers.clear();
	//Deleting lines
	lines.clear();

	//If more internal data is added, update this
}

vector<unsigned int> BusBoss::findLinesinStop(string stopname) {
	vector<unsigned int> output;

	//loop goes through all the lines in the map
	//(works like a for each in which each it is an iterator but can be used to directly access the map element, kind of)
	for (auto const &it : lines) {
		//If the given stop is in the list of stops, the ID of the line is pushed back into the output
		if (it.second.hasStop(stopname)) {
			output.push_back(it.second.getID()); //.first gets key, .second gets data in key
		}
	}

	//returning the matches found
	return output;
}

vector<BusBoss::schedule> BusBoss::generateStopSchedules(string stop, vector<unsigned int> lineIDs) {
	vector<schedule> output;

	for (int i = 0; i < lineIDs.size(); i++) {
		output.push_back(generateStopSchedules(stop, lineIDs[i]));
	}

	return output;
}

BusBoss::schedule BusBoss::generateStopSchedules(string stop, unsigned int lineID) {
	//Function note: to simplify the math here everything is done as minutes and in the end it is converted to strings

	schedule output;

	//Store the frequency to not have to keep getting the frequency
	int frequency = lines[lineID].getFrequency();

	//Same for stops and travel times
	vector<string> stops = lines[lineID].getStops();
	vector<unsigned int> times = lines[lineID].getTravelTimesBetweenStops();

	//Get start and end times in minutes
	unsigned int startTime = BUS_START_TIME_HOUR * 60 + BUS_START_TIME_MINUTE;
	unsigned int endTime = BUS_END_TIME_HOUR * 60 + BUS_END_TIME_MINUTE;

	//Get travel duration to the given stop from the start and from end
	unsigned int travelTimeFromStart = 0;
	for (int i = 0; i < stops.size(); i++) {
		if (stops[i] == stop) {
			//The stop was found
			break;
		}
		else {
			//Add travel time from this stop to the next one because this is not the one we want
			travelTimeFromStart += times[i];
			//There is no problem with getting out of bounds because at most the loop will break at stops.size which is one more than delaybetweenstops.size
		}
	}

	unsigned int travelTimeFromEnd = 0;
	for (int i = stops.size() - 1; i >= 0; i--) {
		if (stops[i] == stop) {
			//The stop was found
			break;
		}
		else {
			//Add travel time from this stop to the next one because this is not the one we want
			travelTimeFromEnd += times[i - 1]; //-1 because delays have 1 less index than stops
		}
	}

	//Times at which the buses start the line (direction does not matter for this because we are considering that buses depart from start and end simultaneously)
	vector<unsigned int> busDepartures;

	//Filling the vector 
	// Discarded: the stop condition is if the bus cannot make it to one of the endings of the line, he does not depart
	// Now using pure "if before the time of end of service" as a stop condition due to teacher suggestion
	for (int currentTime = startTime; currentTime < endTime; currentTime += frequency) {
		busDepartures.push_back(currentTime);
	}

	//Times at which the bus passes at the given stop
	vector<int> positiveBusPassagesAtStop; //In the positive direction (start to finish)
	vector<int> negativeBusPassagesAtStop; //In the negative direction (finish to start)

	//Filling vector of bus passages at the given stop
	for (int i = 0; i < busDepartures.size(); i++) {
		positiveBusPassagesAtStop.push_back(busDepartures[i] + travelTimeFromStart);
		negativeBusPassagesAtStop.push_back(busDepartures[i] + travelTimeFromEnd);
	}

	//Setting output schedule values

	//Line ID for printing stop schedule
	output.lineID = lineID;

	//Dealing with the stop being the end or the beginning of the line

	//If the stop is the end, it makes no sense to show the positive timetable

	if (stop == stops[stops.size() - 1])
		output.positiveBusTimes = vector<string>();
	else
		output.positiveBusTimes = Utilities::minutesToHHMM(positiveBusPassagesAtStop);

	//Likewise, if the stop is the beginning, it makes no sense to show the negative timetable

	if (stop == stops[0])
		output.negativeBusTimes = vector<string>();
	else
		output.negativeBusTimes = Utilities::minutesToHHMM(negativeBusPassagesAtStop);

	return output;
}

vector<BusBoss::route> BusBoss::calculateRouteSameLine(string startStop, string endStop, vector<unsigned int> commonLines) {
	//vector of distances, distance has the ID for the line, the direction and the number of stops to go through (to compare each line)
	vector<route> output(commonLines.size());

	for (int i = 0; i < commonLines.size(); i++) {
		//output was already with the correct dimensions so there is no need to use push_back
		output[i] = calculateRouteSameLine(startStop, endStop, commonLines[i]);
	}

	return output;
}

BusBoss::route BusBoss::calculateRouteSameLine(string startStop, string endStop, unsigned int commonLineID) {
	route r;

	//This is in the same line so there are no switches
	r.switchesline = false;

	//Setting line ID to be able to know which line we are referring to in the future
	r.lineIDs.first = commonLineID;

	//Getting the stops vector for this line
	vector<string> stops = lines[commonLineID].getStops();

	//finding the startStop position in the given line
	int startpos = lines[commonLineID].findStop(startStop);

	//finding the endStop position in the given line
	int endpos = lines[commonLineID].findStop(endStop);

	//Getting the total time for comparison with other routes
	vector<unsigned int> times = lines[commonLineID].getTravelTimesBetweenStops();
	unsigned int totalTime = 0;

	//start is left of end - positive direction
	if (startpos < endpos) {
		r.directions.first = 1;
		r.nStops.first = endpos - startpos;

		//Calculating times based on direction
		for (int i = startpos; i < endpos; ++i) {
			totalTime += times[i];
		}
	}
	else {
		//start is right of end - negative direction
		r.directions.first = -1;
		r.nStops.first = startpos - endpos;

		//Calculating times based on direction
		for (int i = endpos; i < startpos; ++i) {
			totalTime += times[i];
		}
	}

	//Setting the total time
	r.totalTimeinMinutes = totalTime;

	return r;
}

vector<BusBoss::route> BusBoss::calculateRouteSwitch(string stop1, string stop2, const vector<unsigned int>& foundLinesStop1, const vector<unsigned int>& foundLinesStop2) {

	vector<route> output;

	//Vectors that hold the stops being compared
	vector<string> outerstops;
	vector<string> innerstops;

	//For each line of stop1
	for (unsigned int outerline : foundLinesStop1) {
		outerstops = lines[outerline].getStops();

		//Searching for each stop of the current line of stop1
		for (string outerstop : outerstops) {

			//Because we wouldn't switch the line at the first stop anyway, that would be going on the same line (I think)
			if (outerstop == stop1)
				continue;

			//For each line of stop2, 
			for (unsigned int innerline : foundLinesStop2) {
				//if the line is the same, then a "switch" would be possible on every stop, thus making the system not work, so if the line is the same, we skip the line
				if (innerline == outerline)
					continue;

				innerstops = lines[innerline].getStops();

				for (string innerstop : innerstops) {
					//Because we wouldn't switch the line at the last stop anyway, that would be going on the same line (I think)
					if (innerstop == stop2)
						continue;

					//If a common stop is found between the lines of stop1 and stop2, the route is generated and appended to the output
					if (innerstop == outerstop)
						output.push_back(calculateRouteSwitch(stop1, stop2, innerstop, outerline, innerline));
				}

			}

		}

	}

	return output;
}

BusBoss::route BusBoss::calculateRouteSwitch(string stop1, string stop2, string commonstop, unsigned int stop1line, unsigned int stop2line) {
	route r;

	//This function only calculates routes when switching lines
	r.switchesline = true;

	//Setting the line IDs
	r.lineIDs = { stop1line, stop2line };

	//Getting position of stops in their respective lines
	unsigned int stop1pos = lines[stop1line].findStop(stop1);
	unsigned int commonstopline1pos = lines[stop1line].findStop(commonstop);
	unsigned int commonstopline2pos = lines[stop2line].findStop(commonstop);
	unsigned int stop2pos = lines[stop2line].findStop(stop2);

	//Getting data depending on direction

	//Getting the time from stop1 to commonstop
	vector<unsigned int> times = lines[stop1line].getTravelTimesBetweenStops();
	unsigned int totalTime = 0;

	//stop1 to commonstop
	//stop1 is left of commonstop - positive direction
	if (stop1pos < commonstopline1pos) {
		r.directions.first = 1;
		r.nStops.first = commonstopline1pos - stop1pos;

		//Getting time based on direction
		for (int i = stop1pos; i < commonstopline1pos; ++i) {
			totalTime += times[i];
		}
	}
	else {
		//stop1 is right of commonstop - negative direction
		r.directions.first = -1;
		r.nStops.first = stop1pos - commonstopline1pos;

		//Getting time based on direction
		for (int i = commonstopline1pos; i < stop1pos; ++i) {
			totalTime += times[i];
		}
	}

	//Getting the time from commonstop to stop2
	times = lines[stop2line].getTravelTimesBetweenStops();

	//commonstop to stop2
	//commonstop is left of stop2 - positive direction
	if (commonstopline2pos < stop2pos) {
		r.directions.second = 1;
		r.nStops.second = stop2pos - commonstopline2pos;

		//Getting time based on direction
		for (int i = commonstopline2pos; i < stop2pos; ++i) {
			totalTime += times[i];
		}
	}
	else {
		//stop1 is right of commonstop - negative direction
		r.directions.second = -1;
		r.nStops.second = commonstopline2pos - stop2pos;

		//Getting time based on direction
		for (int i = stop2pos; i < commonstopline2pos; ++i) {
			totalTime += times[i];
		}
	}

	//Setting the total time
	r.totalTimeinMinutes = totalTime;

	return r;
}

void BusBoss::listBusUnassignedPeriodsByLine(unsigned int lineID) {

	//Getting bus fleet
	vector<Bus> busFleet = lines[lineID].getBusFleet();

	//Used to temporarily save the bus shifts
	vector<Shift> tempShifts;

	//for each bus in the line
	for (auto const &bus : busFleet) {
		cout << "Autocarro n� " << bus.getBusOrderInLine() << " de " << busFleet.size() << ":" << endl;
		tempShifts = bus.getRemainingWork();

		if (tempShifts.empty()) {
			cout << "Este autocarro j� tem todo o seu trabalho atribu�do." << endl;
		}
		else {
			cout << "Trabalho que ainda falta atribuir condutor a:" << endl;

			//for each remaining shift in the bus - printing the times that are missing a driver
			for (auto const &shift : tempShifts) {
				auto startTime = Utilities::minutesToTime(shift.getStartTime());
				auto endTime = Utilities::minutesToTime(shift.getEndTime());
				cout << "In�cio do turno: " << startTime << "\t";
				cout << "Fim do turno: " << endTime << endl;
			}
		}

		//Spacing
		cout << endl;
	}
}

void BusBoss::listBusUnassignedPeriodsByLineAndWeekday(unsigned int lineID, unsigned int desiredWeekday) {

	//Getting bus fleet
	vector<Bus> busFleet = lines[lineID].getBusFleet();

	//Used to temporarily save the bus shifts
	vector<Shift> tempShifts;

	//for each bus in the line
	for (auto const &bus : busFleet) {
		cout << "Autocarro n� " << bus.getBusOrderInLine() << " de " << busFleet.size() << ":" << endl;
		tempShifts = bus.getRemainingWork();

		if (tempShifts.empty()) {
			cout << "Este autocarro j� tem todo o seu trabalho atribu�do." << endl;
		}
		else {

			//Shifts to print (that are in the requested day)
			vector<Shift> shiftsToPrint;

			//Finding shifts to print
			for (const auto &shift : tempShifts) {
				auto startTime = Utilities::minutesToTime(shift.getStartTime());
				if (startTime.weekday == desiredWeekday)
					shiftsToPrint.push_back(shift);
			}

			//Checking if there are shifts to print (if shiftsToPrint is empty there are none)
			if (shiftsToPrint.empty()) {
				cout << "Este autocarro n�o tem turnos por atribuir no dia requesitado." << endl;
			}
			else {
				//else print

				//for each shift to print - printing the times that are missing a driver
				for (auto const &shift : shiftsToPrint) {
					auto startTime = Utilities::minutesToTime(shift.getStartTime());
					auto endTime = Utilities::minutesToTime(shift.getEndTime());
					cout << "In�cio do turno: " << startTime << "\t";
					cout << "Fim do turno: " << endTime << endl;
				}
			}
		}

		//Spacing
		cout << endl;
	}
}

vector<Shift> BusBoss::listBusUnassignedPeriodsByLineWeekdayAndBusOrderNumber(unsigned int lineID, unsigned int desiredWeekday, unsigned int busOrderNumber) {

	//Output to return
	vector<Shift> possibleShifts;

	//Getting bus fleet
	vector<Bus> busFleet = lines[lineID].getBusFleet();

	//Used to temporarily save the bus shifts
	vector<Shift> tempShifts;

	//for each bus in the line
	for (auto const &bus : busFleet) {
		//Only print or do anything if this is the correct bus
		if (bus.getBusOrderInLine() == busOrderNumber) {
			tempShifts = bus.getRemainingWork();
			if (tempShifts.empty()) {
				cout << "Este autocarro j� tem todo o seu trabalho atribu�do." << endl;
			}
			else {

				//Finding the shifts to print (that are in the requested day)

				for (const auto &shift : tempShifts) {
					auto startTime = Utilities::minutesToTime(shift.getStartTime());
					if (startTime.weekday == desiredWeekday)
						possibleShifts.push_back(shift);
				}

				//Checking if there are shifts to print (if shiftsToPrint is empty there are none)
				if (possibleShifts.empty()) {
					cout << "Este autocarro n�o tem turnos por atribuir no dia requesitado." << endl;
				}
				else {
					//else print

					//for each shift to print - printing the times that are missing a driver
					for (auto const &shift : possibleShifts) {
						auto startTime = Utilities::minutesToTime(shift.getStartTime());
						auto endTime = Utilities::minutesToTime(shift.getEndTime());
						cout << "In�cio do turno: " << startTime << "\t";
						cout << "Fim do turno: " << endTime << endl;
					}
				}
			}
		}
	}

	//Spacing
	cout << endl;

	//returning the possible shifts for input validation in other functions
	return possibleShifts;
}

void BusBoss::printDriverShifts(unsigned int driverID) {
	//Getting shifts vector
	vector<Shift> shifts = drivers[driverID].getShifts();


	if (shifts.empty()) {
		cout << "O condutor em quest�o n�o tem trabalho atribu�do." << endl;
	}
	else {
		cout << "O condutor tem " << shifts.size() << (shifts.size() > 1 ? " turnos atribu�dos." : " turno atribu�do.") << endl;
		for (int i = 0; i < shifts.size(); i++) {
			cout << "Turno n� " << i + 1 << ":\n";
			cout << shifts[i] << endl;
		}
	}

}

bool BusBoss::canFitInShiftInterval(unsigned int startTime, unsigned int endTime, const vector<Shift> &possibleShifts) {

	//Taking the startTime and endTime and converting them to hourly intervals
	//(this removes the possibilty of having a shift from 10:00 to 11:05 in a bus that works 09:00 to 12:00, which should be possible, but it doesn't matter because that would be much harder to implement, and time is of the essence at the moment as well)
	vector<unsigned int> hourlyIntervals;

	for (unsigned int currentTime = startTime; currentTime < endTime; currentTime += 60) {
		hourlyIntervals.push_back(currentTime);
	}

	//Since both the startTime->endTime interval and the time interval given by the vector of shifts are sorted and continuous,
	//we can check the hourly intervals against the start times, and if there is a match for every hourly interval, the shift can fit, otherwise it cannot

	//Helper flag that defines if a time was found in the shifts vector, to allow breaking
	bool timeFound = false;

	for (unsigned int currentTime : hourlyIntervals) {

		//Resetting flag in between iterations
		timeFound = false;

		for (const auto &shift : possibleShifts) {
			//If the time was found we break the inner seach loop and set the found flag to true
			if (shift.getStartTime() == currentTime) {
				timeFound = true;
				break;
			}
		}

		//If any of the times was not found, then the function returns false, because the given time interval cannot fit in the vector of shifts
		if (!timeFound) {
			return false;
		}

	}

	//If the loop was not broken, there was a match for every element, so the time interval can fit in the shift interval
	return true;
}

string BusBoss::getDirection(unsigned int lineID, short int direction) {

	string output;

	//Positive direction
	if (direction == 1) {
		output = lines[lineID].getLastStop();
	}
	//Negative direction
	else {
		output = lines[lineID].getFirstStop();
	}

	return output;
}

void BusBoss::saveDriverstoFile(ostream &file) {

	//Text lines are supposed to be in the following format:
	// ID ; Name ; Shift size ; Weekly hour limit ; Minimum rest time
	// (With a new line between each line)

	//Getting an iterator to access all the elements in the drivers map (constant because there is no need to change)
	auto driverit = drivers.cbegin();

	//First item done outside so that the newline can be appended before to cause for no newline at the end or start of the file
	//(Also the reason to not use a range based for loop - accessing first item separately)
	file << driverit->second.getID() << " ; " << driverit->second.getName() << " ; "
		<< driverit->second.getShiftSize() << " ; " << driverit->second.getWeeklyHourLimit() << " ; " << driverit->second.getMinRestTime();

	//For loop with the iterator, incremented at the start because the first element was already saved
	//Note: ++it avoids extra copy operation (see code generated by pre-increment vs post-increment for iterators) 
	for (++driverit; driverit != drivers.cend(); ++driverit) {
		file << "\n" << driverit->second.getID() << " ; " << driverit->second.getName() << " ; "
			<< driverit->second.getShiftSize() << " ; " << driverit->second.getWeeklyHourLimit() << " ; " << driverit->second.getMinRestTime();
	}

	//Driver file updated.
}

void BusBoss::saveLinestoFile(ostream &file) {

	//Text lines are supposed to be in the following format
	// ID ; bus frequency ; stops list separated by ',' ; delays list separated by ','
	// (With a new line between each line)

	//Getting an iterator to access all the elements in the drivers map (constant because there is no need to change)
	auto lineit = lines.cbegin();

	//First item done outside so that the newline can be appended before to cause for no newline at the end or start of the file
	//(Also the reason to not use a range based for loop - accessing first item separately)
	file << lineit->second.getID() << " ; " << lineit->second.getFrequency() << " ; ";

	//Getting stops vector into a temporary vector (also used for the other lines)
	vector<string> stops = lineit->second.getStops();

	//First index of stops list also done outside so ',' can be appended to the left
	file << stops[0];

	//Stops list separated by ','
	for (int j = 1; j < stops.size(); j++) {
		file << ", " << stops[j];
	}

	//Separator between stops list and delays list
	file << "; ";

	//Getting time between stops vector into a temporary vector (also used for the other lines)
	vector<unsigned int> times = lineit->second.getTravelTimesBetweenStops();

	//First index of delays list also done outside so ',' can be appended to the left
	file << times[0];

	//Delays list separated by ','
	for (int k = 1; k < times.size(); k++) {
		file << ", " << times[k];
	}


	//For loop with the iterator, incremented at the start because the first element was already saved
	//Note: ++it avoids extra copy operation (see code generated by pre-increment vs post-increment for iterators)
	for (++lineit; lineit != lines.cend(); ++lineit) {
		file << "\n" << lineit->second.getID() << " ; " << lineit->second.getFrequency() << " ; ";

		//Getting stops vector
		stops = lineit->second.getStops();

		//First index of stops list also done outside so ',' can be appended to the left
		file << stops[0];

		//Stops list separated by ','
		for (int j = 1; j < stops.size(); j++) {
			file << ", " << stops[j];
		}

		//Separator between stops list and delays list
		file << "; ";

		//Getting time between stops vector
		times = lineit->second.getTravelTimesBetweenStops();

		//First index of delays list also done outside so ',' can be appended to the left
		file << times[0];

		//Delays list separated by ','
		for (int k = 1; k < times.size(); k++) {
			file << ", " << times[k];
		}

	}

	//Lines file updated.
}

ostream& operator<<(ostream &os, const Line &l) {
	os << "ID: " << l.getID() << "\nFrequ�ncia de passagem de autocarros: " << l.getFrequency();
	os << "\nParagens desta linha:\n";
	Utilities::printVector(l.getStops());
	os << "Tempos de viagem entre estas paragens:\n";
	Utilities::printVector(l.getTravelTimesBetweenStops());

	return os;
}

ostream& operator<<(ostream &os, const Driver &d) {
	cout << "ID: " << d.getID() << "\nNome: " << d.getName();
	cout << "\nTamanho de turno: " << d.getShiftSize() << "\nLimite de horas de trabalho semanal: " << d.getWeeklyHourLimit();
	cout << "\nTempo m�nimo de descanso: " << d.getMinRestTime() << endl;

	return os;
}

ostream& operator<<(ostream &os, const Shift &s) {
	os << "ID da linha: " << s.getLineID() << "\nID do condutor: " << s.getDriverID();
	os << "\nN�mero de ordem do autocarro na linha: " << s.getBusOrderNumber() << endl;
	os << "Tempo de in�cio: ";
	auto starttime = Utilities::minutesToTime(s.getStartTime());
	os << Utilities::weekdays[starttime.weekday] << ", " << starttime.hourAndMinutes << endl;
	os << "\t\tTempo de fim: ";
	auto endtime = Utilities::minutesToTime(s.getEndTime());
	os << Utilities::weekdays[endtime.weekday] << ", " << endtime.hourAndMinutes << endl;

	return os;
}

ostream& operator <<(ostream &os, const Bus &b) {
	os << "ID da linha: " << b.getLineID();

	os << "\nN�mero de ordem na linha: " << b.getBusOrderInLine();

	os << "\nHora de in�cio do servi�o do autocarro: " << Utilities::minutesToHHMM(b.getStartTime());

	os << "\nHora de fim de servi�o do autocarro: " << Utilities::minutesToHHMM(b.getEndTime()) << endl;

	return os;
}

ostream& operator <<(ostream &os, const Utilities::time &t) {
	os << Utilities::weekdays[t.weekday] << " " << t.hourAndMinutes;
	return os;
}

bool BusBoss::route::operator<(const BusBoss::route &r) const {
	return totalTimeinMinutes < r.totalTimeinMinutes;
}